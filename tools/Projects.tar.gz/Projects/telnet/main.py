#!/usr/bin/env  python3


from getpass import getpass
from telnetlib import Telnet


host_ipv6_address = "2001:db8:cafe::1"
user = "cesar"
password = "cesar"
# user = input(f"Ingresa el usuario para {host_ipv6_address}: ")
# password = getpass(prompt=f"Escribe el password para {host_ipv6_address}: ")

try:
    telnet_connection = Telnet(host=host_ipv6_address)

    telnet_connection.read_until(b"Username: ")
    telnet_connection.write(user.encode("ascii") + b"\n")

    if password:
        telnet_connection.read_until(b"Password: ")
        telnet_connection.write(password.encode("ascii") + b"\n")

    telnet_connection.write(b"terminal length 0\r\n")
    telnet_connection.write(b"show run | section hostname\r\n")
    telnet_connection.write(b"show version\r\n")
    telnet_connection.write(b"\nexit \n")

    output = telnet_connection.read_all().decode("ascii").splitlines()

    telnet_connection.close()

    # print(f"{output}")

    dic_device = {}
    for data in output:
        if "hostname" in data.lower():
            dic_device["Hostname"] = data.split(sep=" ")[-1]
            continue

        elif "iosv" in data.lower():
            for datum in data.split(sep=","):
                if "version" in datum.lower():
                    dic_device["Version"] = datum.strip().split(sep=" ")[-1]
                    break
            continue

    
    print(f"\r\n\nInformation of \"{host_ipv6_address}\"\r\n{dic_device}\n")

except ConnectionRefusedError:
    print(f"Connection with {host_ipv6_address} is forbbiden.")

except KeyboardInterrupt:
    print(f"You aborted the operation with keyboard.")

finally:
    print(f"The connection with {host_ipv6_address} is finished")


# print(output)


# for data in output.splitlines():
#    print(data)
