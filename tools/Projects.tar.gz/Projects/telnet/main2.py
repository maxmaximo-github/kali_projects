#!/usr/bin/env  python3


from getpass import getpass
from telnetlib import Telnet


host_ipv6_address = "2001:db8:cafe::1"
user = input(f"Ingresa el usuario para {host_ipv6_address}: ")
password = getpass(prompt=f"Escribe el password para {host_ipv6_address}: ")

with Telnet(host=host_ipv6_address) as telnet_connection:
    telnet_connection.read_until(b"Username: ")
    telnet_connection.write(user.encode("ascii") + b"\n")

    if password:
        telnet_connection.read_until(b"Password: ")
        telnet_connection.write(password.encode("ascii") + b"\n")

    telnet_connection.write(b"show version \r\n")
    telnet_connection.write(b" exit \n")

    print(telnet_connection.read_all().decode("ascii"))